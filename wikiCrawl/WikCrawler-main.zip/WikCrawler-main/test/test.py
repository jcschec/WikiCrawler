#!/usr/bin/env python3
import unittest
import sys
from WikCrawler import *

def getSummary(self):
    result = info.getSummary(self)
    print(result)

#getSummary('Linux')