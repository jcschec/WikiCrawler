"""WikCrawler is used to get information about anything on the shell using Wikipedia"""

__version__ = "1.0"
name = "WikCrawler"
__all__ = ['WikCrawler','info']
import WikCrawler
from WikCrawler import *