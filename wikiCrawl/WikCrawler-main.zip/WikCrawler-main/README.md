To install from source use commands:

1   sudo pip3 install -r requirements.txt
    or 
    sudo pip3 install beautifulsoup4 flit_core 
    
2   git clone https://github.com/quipthaw/WikCrawler.git

3   cd WikCrawler

4   sudo pip3 install .


test: 
    user$ WikCrawler -i Linux